﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Zadanie
{
    /// <summary>
    /// Логика взаимодействия для Flag.xaml
    /// </summary>
    public partial class Flag : Window
    {
        public Flag()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            SolidColorBrush BlueColor = new SolidColorBrush(Color.FromRgb(0,0,255));
            SolidColorBrush RedColor = new SolidColorBrush(Color.FromRgb(255, 0, 0));
            SolidColorBrush GreenColor = new SolidColorBrush(Color.FromRgb(0, 255, 0));

            if (rbnBlue1.IsChecked == true) txbflag1.Background = BlueColor;
            if (rbnRed1.IsChecked == true) txbflag1.Background = RedColor;
            if (rbnGreen1.IsChecked == true) txbflag1.Background = GreenColor;
            if (rbnBlue2.IsChecked == true) txbflag2.Background = BlueColor;
            if (rbnRed2.IsChecked == true) txbflag2.Background = RedColor;
            if (rbnGreen2.IsChecked == true) txbflag2.Background = GreenColor;
            if (rbnBlue3.IsChecked == true) txbflag3.Background = BlueColor;
            if (rbnRed3.IsChecked == true) txbflag3.Background = RedColor;
            if (rbnGreen3.IsChecked == true) txbflag3.Background = GreenColor;
        }
    }
}
